Hello, by downloading IronWASP you have taken the first step towards making your Web Security testing process more efficient.

Simply double-click the file named IronWASP.exe to get started. IronWASP DOES NOT require installation or administrative rights to work.

IMPORTANT: Please read COPYRIGHT.txt before using the software.


There is a DemoApp application available that can be used for testing some of the features of IronWASP. The DemoApp can be started by executing DemoApp.exe.

The Session Plugins packaged with IronWASP are desgined for the DemoApp, they can be used as reference for creating your own Session Plugins.

For more details check the 'About' section in the menu inside IronWASP and the 'Learn' section on ironwasp.org
